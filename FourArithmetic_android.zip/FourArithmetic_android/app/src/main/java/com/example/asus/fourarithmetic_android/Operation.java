package com.example.asus.fourarithmetic_android;


public class Operation {
    public static String[][] topic = new String[100][7];  //题目数组。
    private static int[] operate = new int[2];  //运算符数组，以两个运算符操作。
    private static int[] number = new int[3];  //操作数数组。
    public int topicNum;
    public int n = (int) (1 + Math.random() * 10);   //随机产生1—5的一个数字作为阶乘数。
    public Operation(int topicNum){
       this.topicNum=topicNum;
    }  //构造函数，传递题数。

    //随机产生操作数和运算符。
    public static void getData() {
        for (int jnum = 0; jnum < 3; jnum++) {
            int randomNum = (int) (1 + Math.random() * 100);
            number[jnum] = randomNum;
        }
        for (int jop = 0; jop < 2; jop++) {
            int randomop = (int) (Math.random() * 4);
            operate[jop] = randomop;
        }
    }
    //获取运算符符号。
    public static String getOp(int randomop) {
        if (randomop == 0) {
            return "+";
        }
        if (randomop == 1) {
            return "-";
        }
        if (randomop == 2) {
            return "*";
        }
        if (randomop == 3) {
            return "/";
        }
        return "";

    }
    //加减乘除运算。
    public static double operation(int randomop, double num1, double num2) {
        if (randomop == 0) {
            return num1 + num2;
        }
        if (randomop == 1) {
            return num1 - num2;
        }
        if (randomop == 2) {
            return num1 * num2;
        }
        if (randomop == 3) {
            return num1 / num2;
        }
        return 0;
    }
    //得出运算结果。
    public static double getResult() {
        //第二个运算符为乘法或者除法运算。除法的优先级比乘法的优先级高。
        if (operate[1] >= 2) {
            if (operate[0] == 3) {
                double result = operation(operate[0], number[0], number[1]);
                result = operation(operate[1], result, number[2]);
                result = Double.valueOf(String.format("%10.1f", result));
                return result;
            } else if(operate[1] == 3&&operate[0] == 3){
                double result = operation(operate[1], number[1], number[2]);
                result = operation(operate[0], number[0], result);
                result = Double.valueOf(String.format("%10.1f", result));//保留两位小数。
                return result;
            }else {
                double result = operation(operate[1], number[1], number[2]);
                result = operation(operate[0], number[0], result);
                result = Double.valueOf(String.format("%10.1f", result));
                return result;
            }//顺序运算。
        }
        else {
            double result = operation(operate[0], number[0], number[1]);
            result = operation(operate[1], result, number[2]);
            result=Double.valueOf(String.format("%10.1f", result));
            return result;
        }
    }
    //输入运算结果。
    public static void Scanner(int  topicNum){
        for(int i=0;i< topicNum;i++) {
            getData();
            for (int jnum = 0; jnum < 3; jnum++) {
                topic[i][2 * jnum] = String.valueOf(number[jnum]); //题目数组与操作数数组索引值关系。
            }
            for (int jop = 0; jop < 2; jop++) {
                topic[i][2 * jop + 1] = getOp(operate[jop]);
            }
            topic[i][5] = "=";
            topic[i][6] = String.valueOf(getResult());  //获取正确答案
            if(getResult()<=0){
                {i--;}
            }
        }
    }
    //输出正确答案。
    public static void showTopic(int topicNum){
        System.out.println("正确答案是：");
        for(int i=0;i<topicNum;i++){
            for(int j=0;j<6;j++){
                System.out.print(topic[i][j]);
            }
            System.out.print(topic[i][6]);
            System.out.println();
        }

    }
    //求阶乘。
    public static long getNFactorial(int n){
        if(n==0){
            return 1;
        }
        return n*getNFactorial(n-1);
    }
}

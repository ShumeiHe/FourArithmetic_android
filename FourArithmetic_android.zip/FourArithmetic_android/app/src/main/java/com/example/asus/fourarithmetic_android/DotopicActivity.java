package com.example.asus.fourarithmetic_android;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class DotopicActivity extends AppCompatActivity {
    private String topicNum,factorial;
    private Operation operation;
    private TextView tv_topic;
    private TextView tv_answer;
    private TextView tv_score1, tv_score2,tv_score3,tv_score4,tv_score5;
    private EditText et_input_answer1,et_input_answer2,et_input_answer3,et_input_answer4,et_input_answer5;
    private Button btn_submit,btn_answer,btn_start;
    private ImageButton imageButton;
    private String[] topic=new String[6];
    private String[] answer=new String[6];
    private int n;
    private int score=0;
    private Chronometer chronometer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dotopic);
        getData();
        init();

    }

    //获取从TopicActivity传来的数据。
    public void getData(){
        Intent intent=getIntent();
        topicNum=intent.getStringExtra("topicNum");
        factorial=intent.getStringExtra("factorial");
        operation=new Operation(Integer.parseInt(topicNum));
    }
    private void init(){
        tv_topic=(TextView)findViewById(R.id.tv_topic);
        tv_answer=(TextView)findViewById(R.id.tv_answer);
        tv_score1=(TextView)findViewById(R.id.tv_score1);
        tv_score2=(TextView)findViewById(R.id.tv_score2);
        tv_score3=(TextView)findViewById(R.id.tv_score3);
        tv_score4=(TextView)findViewById(R.id.tv_score4);
        tv_score5=(TextView)findViewById(R.id.tv_score5);
        et_input_answer1=(EditText)findViewById(R.id.et_input_answer1);
        et_input_answer2=(EditText)findViewById(R.id.et_input_answer2);
        et_input_answer3=(EditText)findViewById(R.id.et_input_answer3);
        et_input_answer4=(EditText)findViewById(R.id.et_input_answer4);
        et_input_answer5=(EditText)findViewById(R.id.et_input_answer5);
        btn_submit=(Button)findViewById(R.id.btn_submit);
        btn_answer=(Button)findViewById(R.id.btn_answer);
        btn_start=(Button)findViewById(R.id.btn_start);
        chronometer = (Chronometer) findViewById(R.id.chronometer);
        imageButton=(ImageButton)findViewById(R.id.imageButton);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(DotopicActivity.this,TopicActivity.class);
                startActivity(intent);
            }
        });
        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                input();
                btn_start.setVisibility(View.INVISIBLE);
                chronometer.setBase(SystemClock.elapsedRealtime());
                chronometer.start();
            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_answer.setVisibility(View.VISIBLE);
                chronometer.stop();
                Makking();
                int error=Integer.parseInt(topicNum)-score;
                Toast.makeText(DotopicActivity.this,"您答对"+score+"道题，答错"+error+"道题",Toast.LENGTH_SHORT).show();
                Et_enable();
                btn_submit.setEnabled(false);
            }
        });
        btn_answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                outputAnswer();
            }
        });
    }
    //设置编辑框为不可编辑状态。
    public void Et_enable(){
        et_input_answer1.setFocusableInTouchMode(false);
        et_input_answer2.setFocusableInTouchMode(false);
        et_input_answer3.setFocusableInTouchMode(false);
        et_input_answer4.setFocusableInTouchMode(false);
        et_input_answer5.setFocusableInTouchMode(false);
    }
    //从operation对象中获取题目数组。
    public void getTopic(){
        operation.Scanner(Integer.parseInt(topicNum));
        for(int i=0;i<5;i++){
            topic[i]="";
            for(int j=0;j<6;j++){
                topic[i]=topic[i]+operation.topic[i][j];
            }
        }
        n=operation.n;
        topic[5]=String.valueOf(n)+"!";
    }
    ////从operation对象中获取题目数组的答案。
    public void getAnswer(){
        for(int i=0;i<5;i++){
            answer[i]=operation.topic[i][6];
        }
        answer[5]=String.valueOf(operation.getNFactorial(n)).trim();
    }
    //输出题目
    public void input(){

        getTopic();
        switch (Integer.valueOf(topicNum)){
            case 1:{
                if(factorial.equals("是")){
                    tv_topic.setText("(1)"+topic[5]);
                }else{
                    tv_topic.setText("(1)"+topic[0]);
                }
                et_input_answer1.setVisibility(View.VISIBLE);
                break;
            }case 2:{
                if(factorial.equals("是")){
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[5]);
                }else{
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[1]);
                }
                et_input_answer1.setVisibility(View.VISIBLE);
                et_input_answer2.setVisibility(View.VISIBLE);
                break;
            }case 3:{
                if(factorial.equals("是")){
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[1]+"\n"+"\n"+"(3)"+topic[5]);
                }else{
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[1]+"\n"+"\n"+"(3)"+topic[2]);
                }

                et_input_answer1.setVisibility(View.VISIBLE);
                et_input_answer2.setVisibility(View.VISIBLE);
                et_input_answer3.setVisibility(View.VISIBLE);
                break;
            }case 4:{
                if(factorial.equals("是")){
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[1]+"\n"+"\n"+"(3)"+topic[2]+"\n"+"\n"+"(4)"+topic[5]);
                }else{
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[1]+"\n"+"\n"+"(3)"+topic[2]+"\n"+"\n"+"(4)"+topic[3]);
                }
                et_input_answer1.setVisibility(View.VISIBLE);
                et_input_answer2.setVisibility(View.VISIBLE);
                et_input_answer3.setVisibility(View.VISIBLE);
                et_input_answer4.setVisibility(View.VISIBLE);
                break;
            }case 5:{
                if(factorial.equals("是")){
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[1]+"\n"+"\n"+"(3)"+topic[2]+"\n"+"\n"+"(4)"+topic[3]+"\n"+"\n"+"(5)"+topic[5]);
                }else{
                    tv_topic.setText("(1)"+topic[0]+"\n"+"\n"+"(2)"+topic[1]+"\n"+"\n"+"(3)"+topic[2]+"\n"+"\n"+"(4)"+topic[3]+"\n"+"\n"+"(5)"+topic[4]);
                }
                et_input_answer1.setVisibility(View.VISIBLE);
                et_input_answer2.setVisibility(View.VISIBLE);
                et_input_answer3.setVisibility(View.VISIBLE);
                et_input_answer4.setVisibility(View.VISIBLE);
                et_input_answer5.setVisibility(View.VISIBLE);
                break;
            }
        }
    }
    //计算答对的题数。
    public int Makking(){
        getAnswer();
        switch (Integer.valueOf(topicNum)){
            case 1:{
                if(factorial.equals("是")){
                    if(et_input_answer1.getText().toString().trim().equals(answer[5])){
                        score+=1;
                        tv_score1.setText("√");
                    }else{
                        tv_score1.setText("X");
                    }
                }else {
                    if (et_input_answer1.getText().toString().trim().equals(answer[0])) {
                        score += 1;
                        tv_score1.setText("√");
                    }else{
                        tv_score1.setText("X");
                    }
                }
                break;
            }case 2:{
                if( et_input_answer1.getText().toString().trim().equals(answer[0])){
                    score+=1;
                    tv_score1.setText("√");
                }else{
                    tv_score1.setText("X");
                }
                if(factorial.equals("是")){
                    if(et_input_answer2.getText().toString().trim().equals(answer[5])){
                        score+=1;
                        tv_score2.setText("√");
                    } else{
                        tv_score2.setText("X");
                    }
                }else {
                    if (et_input_answer2.getText().toString().trim().equals(answer[1])) {
                        score += 1;
                        tv_score2.setText("√");
                    } else{
                        tv_score2.setText("X");
                    }
                }
                break;
            }case 3:{
                if( et_input_answer1.getText().toString().trim().equals(answer[0])){
                    score+=1;
                    tv_score1.setText("√");
                }else{
                    tv_score1.setText("X");
                }
                if(et_input_answer2.getText().toString().trim().equals(answer[1])){
                    score+=1;
                    tv_score2.setText("√");
                } else{
                    tv_score2.setText("X");
                }
                if(factorial.equals("是")){
                    if(et_input_answer3.getText().toString().trim().equals(answer[5])){
                        score+=1;
                        tv_score3.setText("√");
                    } else{
                        tv_score3.setText("X");
                    }
                }else {
                    if (et_input_answer3.getText().toString().trim().equals(answer[2])) {
                        score += 1;
                        tv_score3.setText("√");
                    } else{
                        tv_score3.setText("X");
                    }
                }
                break;
            }case 4:{
                if(et_input_answer1.getText().toString().trim().equals(answer[0])){
                    score+=1;
                    tv_score1.setText("√");
                }else{
                    tv_score1.setText("X");
                }
                if(et_input_answer2.getText().toString().trim().equals(answer[1])){
                    score+=1;
                    tv_score2.setText("√");
                } else{
                    tv_score2.setText("X");
                }
                if(et_input_answer3.getText().toString().trim().equals(answer[2])){
                    score+=1;
                    tv_score3.setText("√");
                } else{
                    tv_score3.setText("X");
                }
                if(factorial.equals("是")){
                    if(et_input_answer4.getText().toString().trim().equals(answer[5])){
                        score+=1;
                        tv_score4.setText("√");
                    } else{
                        tv_score4.setText("X");
                    }
                }else {
                    if (et_input_answer4.getText().toString().trim().equals(answer[3])) {
                        score += 1;
                        tv_score4.setText("√");
                    } else{
                        tv_score4.setText("X");
                    }
                }
                break;
            }case 5:{
                if( et_input_answer1.getText().toString().trim().equals(answer[0])){
                    score+=1;
                    tv_score1.setText("√");
                }else{
                    tv_score1.setText("X");
                }
                if( et_input_answer2.getText().toString().trim().equals(answer[1])){
                    score+=1;
                    tv_score2.setText("√");
                } else{
                    tv_score2.setText("X");
                }
                if( et_input_answer3.getText().toString().trim().equals(answer[2])){
                    score+=1;
                    tv_score3.setText("√");
                } else{
                    tv_score3.setText("X");
                }
                if( et_input_answer4.getText().toString().trim().equals(answer[3])){
                    score+=1;
                    tv_score4.setText("√");
                } else{
                    tv_score4.setText("X");
                }
                if(factorial.equals("是")){
                    if(et_input_answer5.getText().toString().trim().equals(answer[5])){
                        score+=1;
                        tv_score5.setText("√");
                    } else{
                        tv_score5.setText("X");
                    }
                }else {
                    if (et_input_answer5.getText().toString().trim().equals(answer[4])) {
                        score += 1;
                        tv_score5.setText("√");
                    } else{
                        tv_score5.setText("X");
                    }
                }
                break;
            }
        }
        return score;
    }
    //输出正确答案。
    public void outputAnswer(){
        getAnswer();
        switch (Integer.valueOf(topicNum)){
            case 1:{
                if(factorial.equals("是")){
                    tv_answer.setText("(1)"+answer[5]);
                }else{
                    tv_answer.setText("(1)"+answer[0]);
                }

                break;
            }case 2:{
                if(factorial.equals("是")){
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[5]);
                }else{
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[1]);
                }

                break;
            }case 3:{
                if(factorial.equals("是")){
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[1]+"   (3)"+answer[5]);
                }else{
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[1]+"   (3)"+answer[2]);
                }

                break;
            }case 4:{
                if(factorial.equals("是")){
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[1]+"   (3)"+answer[2]+"   (4)"+answer[5]);
                }else{
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[1]+"   (3)"+answer[2]+"   (4)"+answer[3]);
                }

                break;
            }case 5:{
                if(factorial.equals("是")){
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[1]+"   (3)"+answer[2]+"   (4)"+answer[3]+"   (5)"+answer[5]);
                }else{
                    tv_answer.setText("(1)"+answer[0]+"   (2)"+answer[1]+"   (3)"+answer[2]+"   (4)"+answer[3]+"   (5)"+answer[4]);
                }
                break;
            }
        }
    }
}

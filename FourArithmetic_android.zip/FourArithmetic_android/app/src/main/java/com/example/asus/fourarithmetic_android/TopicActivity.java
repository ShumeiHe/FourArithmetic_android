package com.example.asus.fourarithmetic_android;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class TopicActivity extends AppCompatActivity {

    private EditText et_topicnum;
    private RadioGroup rg_isfactorial;
    private RadioButton rbtn_isfactorial;
    private Button btn_do_topic;
    String topicNum;
    String factorial,minus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic);
        init();
    }

    //控件初始化以及空间的点击事件。

    private void init() {
        et_topicnum=(EditText)findViewById(R.id.et_topicnum);
        rg_isfactorial=(RadioGroup)findViewById(R.id.rg_isfactorial);
        btn_do_topic=(Button)findViewById(R.id.btn_do_topic);
        rg_isfactorial.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                factorial=Factorial();
            }
        });

        btn_do_topic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TopicActivity.this,DotopicActivity.class);
                transferData(intent);
            }
        });
    }
    //获取是否存在阶乘。
    public  String Factorial(){
        rbtn_isfactorial=(RadioButton) findViewById(rg_isfactorial.getCheckedRadioButtonId());
        String factorial=rbtn_isfactorial.getText().toString();
        return factorial;
    }
    //传输数据。
    public void transferData(Intent intent){
        topicNum=et_topicnum.getText().toString().trim();
        if(0>=Integer.parseInt(topicNum)){
            Toast.makeText(TopicActivity.this,"您输入的题数小于1道请重新输入！",Toast.LENGTH_SHORT).show();
        }else if(Integer.parseInt(topicNum)>5){
            Toast.makeText(TopicActivity.this,"您输入的题数大于5道请重新输入！",Toast.LENGTH_SHORT).show();
        }else{
            intent.putExtra("topicNum",topicNum);
            intent.putExtra("factorial",factorial);
            startActivity(intent);
        }

    }
}
